</div> <!-- closing container div -->

<footer class="mt-auto">
    <p class="footer-text mb-0 text-center">© <?= date('Y') ?> Virtual Kitchen. All rights reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
